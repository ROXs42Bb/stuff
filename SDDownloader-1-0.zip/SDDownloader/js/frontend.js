document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.sd-download-button').forEach(function(button) {
        button.addEventListener('click', function () {
            const blockId = button.id.split('-button')[0];
            const container = button.parentNode;
            button.remove();
            const progressContainer = document.createElement('div');
            progressContainer.className = 'sd-progress-container';
            const progressBar = document.createElement('div');
            progressBar.id = `${blockId}-progress-bar`;
            progressBar.className = 'sd-progress-bar';
            progressContainer.appendChild(progressBar);
            const waitMessage = document.createElement('p');
            waitMessage.className = 'sd-wait-message';
            waitMessage.textContent = 'Please wait, your file is ready to download...';
            container.appendChild(progressContainer);
            container.appendChild(waitMessage);
            const totalTime = button.getAttribute('data-timer-interval') * 1000;
            let elapsed = 0;
            const progressInterval = setInterval(() => {
                elapsed += 100;
                progressBar.style.width = `${(elapsed / totalTime) * 100}%`;
                if (elapsed >= totalTime) {
                    clearInterval(progressInterval);
                    checkFileStatus(container, button.getAttribute('data-download-token'));
                }
            }, 100);
            function checkFileStatus(container, downloadToken) {
                const ajaxUrl = sdPluginData.ajaxUrl;
                fetch(`${ajaxUrl}?action=sd_check_file&download_token=${encodeURIComponent(downloadToken)}`)
                    .then(response => response.json())
                    .then(result => {
                        handleFileStatus(result, container);
                    })
                    .catch(() => {
                        waitMessage.textContent = 'There was an error checking the file status.';
                    });
            }
            function handleFileStatus(result, container) {
                progressContainer.remove();
                waitMessage.remove();
                if (result.status === 'success') {
                    createButton('Download Your File', result.link, container);
                } else {
                    const message = document.createElement('p');
                    message.className = 'sd-error-message';
                    message.textContent = result.message || 'File not found. Try the mirror link below.';
                    container.appendChild(message);
                    if (result.status === 'mirror') {
                        createButton('Download from Mirror', result.link, container);
                    }
                }
            }
            function createButton(text, link, container) {
                const newButton = document.createElement('button');
                newButton.className = 'sd-download-button';
                newButton.textContent = text;
                newButton.addEventListener('click', () => window.location.href = link);
                container.appendChild(newButton);
            }
        });
    });
});

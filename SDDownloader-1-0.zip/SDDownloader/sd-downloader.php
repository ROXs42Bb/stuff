<?php
/*
Plugin Name: Secure Downloader
Description: A WordPress plugin that provides secure download links with a progress bar and timer.
Version: 1.0
Author: Vidyarthi
*/
function sd_register_block() {
    wp_register_script('sd-block-editor-js', plugins_url('block.js', __FILE__), ['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'], filemtime(plugin_dir_path(__FILE__) . 'block.js'), true);
    wp_register_style('sd-frontend-style', plugins_url('css/style.css', __FILE__), [], filemtime(plugin_dir_path(__FILE__) . 'css/style.css'));
    wp_register_script('sd-frontend-js', plugins_url('js/frontend.js', __FILE__), [], filemtime(plugin_dir_path(__FILE__) . 'js/frontend.js'), true);

    register_block_type('sd/download-button', [
        'editor_script'   => 'sd-block-editor-js',
        'style'           => 'sd-frontend-style',
        'render_callback' => 'sd_render_download_block',
        'attributes'      => [
            'mainLink'      => ['type' => 'string', 'default' => ''],
            'mirrorLink'    => ['type' => 'string', 'default' => ''],
            'timerInterval' => ['type' => 'number', 'default' => 10],
            'buttonText'    => ['type' => 'string', 'default' => 'Start Download'],
            'iconSVG'       => ['type' => 'string', 'default' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path fill-rule="evenodd" d="M5.625 1.5H9a3.75 3.75 0 013.75 3.75v1.875c0 1.036.84 1.875 1.875 1.875H16.5a3.75 3.75 0 013.75 3.75v7.875c0 1.035-.84 1.875-1.875 1.875H5.625a1.875 1.875 0 01-1.875-1.875V3.375c0-1.036.84-1.875 1.875-1.875zm5.845 17.03a.75.75 0 001.06 0l3-3a.75.75 0 10-1.06-1.06l-1.72 1.72V12a.75.75 0 00-1.5 0v4.19l-1.72-1.72a.75.75 0 00-1.06 1.06l3 3z" clip-rule="evenodd"/><path d="M14.25 5.25a5.23 5.23 0 00-1.279-3.434"/></svg>'],
        ],
    ]);
}
add_action('init', 'sd_register_block');
function sd_enqueue_frontend_assets() {
    if (is_singular() && has_block('sd/download-button')) {
        wp_enqueue_style('sd-frontend-style');
        wp_enqueue_script('sd-frontend-js');
        wp_localize_script('sd-frontend-js', 'sdPluginData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
        ]);
    }
}
add_action('wp_enqueue_scripts', 'sd_enqueue_frontend_assets');
function sd_render_download_block($attributes) {
    $main_link = esc_url($attributes['mainLink']);
    $mirror_link = esc_url($attributes['mirrorLink']);
    $timer_interval = intval($attributes['timerInterval']);
    $block_id = uniqid('sd-download-block-');
    $button_text = esc_html($attributes['buttonText'] ?: 'Start Download');
    $icon_svg = $attributes['iconSVG'];
    $download_token = wp_generate_password(12, false);
    set_transient('sd_download_' . $download_token, [
        'main_link'   => $main_link,
        'mirror_link' => $mirror_link,
    ], 3600);
    ob_start(); ?>
    <div id="<?php echo esc_attr($block_id); ?>" class="sd-container">
        <button id="<?php echo esc_attr($block_id); ?>-button" class="sd-download-button" data-download-token="<?php echo esc_attr($download_token); ?>" data-timer-interval="<?php echo esc_attr($timer_interval); ?>">
            <?php if (!empty($icon_svg)) {
                echo $icon_svg;
            } ?>
            <?php echo $button_text; ?>
        </button>
    </div>
    <?php
    return ob_get_clean();
}
function sd_check_file_status() {
    $download_token = sanitize_text_field($_GET['download_token'] ?? '');
    $download_data = get_transient('sd_download_' . $download_token);
    if (!$download_data) {
        echo json_encode(['status' => 'error', 'message' => 'Sorry, file not available at the moment.']);
        wp_die();
    }
    $main_link = esc_url_raw($download_data['main_link']);
    $mirror_link = esc_url_raw($download_data['mirror_link']);
    if ($main_link) {
        $response = wp_remote_head($main_link);
        $response_code_main = wp_remote_retrieve_response_code($response);
        if ($response_code_main === 200) {
            echo json_encode(['status' => 'success', 'link' => $main_link]);
            wp_die();
        }
    }
    if ($mirror_link) {
        $response = wp_remote_head($mirror_link);
        $response_code_mirror = wp_remote_retrieve_response_code($response);
        if ($response_code_mirror === 200) {
            echo json_encode(['status' => 'mirror', 'link' => $mirror_link]);
            wp_die();
        }
    }
    echo json_encode(['status' => 'error', 'message' => 'Sorry, file not available at the moment.']);
    wp_die();
}
add_action('wp_ajax_sd_check_file', 'sd_check_file_status');
add_action('wp_ajax_nopriv_sd_check_file', 'sd_check_file_status');

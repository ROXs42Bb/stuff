(function (blocks, editor, element, components) {
    const el = element.createElement;
    const { InspectorControls } = editor;
    const { PanelBody, TextControl, RangeControl, TextareaControl } = components;

    blocks.registerBlockType('sd/download-button', {
        title: 'Secure Download Button',
        icon: 'download',
        category: 'common',
        attributes: {
            mainLink: { type: 'string', default: '' },
            mirrorLink: { type: 'string', default: '' },
            timerInterval: { type: 'number', default: 10 },
            buttonText: { type: 'string', default: 'Start Download' },
            iconSVG: { type: 'string', default: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path fill-rule="evenodd" d="M5.625 1.5H9a3.75 3.75 0 013.75 3.75v1.875c0 1.036.84 1.875 1.875 1.875H16.5a3.75 3.75 0 013.75 3.75v7.875c0 1.035-.84 1.875-1.875 1.875H5.625a1.875 1.875 0 01-1.875-1.875V3.375c0-1.036.84-1.875 1.875-1.875zm5.845 17.03a.75.75 0 001.06 0l3-3a.75.75 0 10-1.06-1.06l-1.72 1.72V12a.75.75 0 00-1.5 0v4.19l-1.72-1.72a.75.75 0 00-1.06 1.06l3 3z" clip-rule="evenodd"/><path d="M14.25 5.25a5.23 5.23 0 00-1.279-3.434 9.768 9.768 0 016.963 6.963A5.23 5.23 0 0016.5 7.5h-1.875a.375.375 0 01-.375-.375V5.25z" /></svg>' },
        },
        edit: function (props) {
            const { attributes, setAttributes } = props;

            // Function to sanitize and allow only the <svg> tag
            const sanitizeSVG = (svgCode) => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(svgCode, 'image/svg+xml');
                const svgElement = doc.querySelector('svg');

                // If no <svg> tag is found, return an empty string
                if (!svgElement) {
                    return '';
                }

                // Serialize the valid <svg> element back to string
                return new XMLSerializer().serializeToString(svgElement);
            };

            return el(
                'div',
                { className: 'sd-download-block' },
                el(InspectorControls, {},
                    el(PanelBody, { title: 'Download Settings', initialOpen: true },
                        el(TextControl, {
                            label: 'Main Download Link',
                            value: attributes.mainLink,
                            onChange: (newValue) => setAttributes({ mainLink: newValue })
                        }),
                        el(TextControl, {
                            label: 'Mirror Download Link',
                            value: attributes.mirrorLink,
                            onChange: (newValue) => setAttributes({ mirrorLink: newValue })
                        }),
                        el(TextControl, {
                            label: 'Button Text',
                            value: attributes.buttonText,
                            onChange: (newValue) => setAttributes({ buttonText: newValue })
                        }),
                        el(RangeControl, {
                            label: 'Timer Interval (in seconds)',
                            value: attributes.timerInterval,
                            onChange: (newValue) => setAttributes({ timerInterval: newValue }),
                            min: 1,
                            max: 60
                        }),
                        el(TextareaControl, {
                            label: 'SVG Code',
                            value: attributes.iconSVG,
                            onChange: (newValue) => setAttributes({ iconSVG: sanitizeSVG(newValue) }),
                            help: 'Paste your SVG code here. Only the <svg> tag and its attributes are allowed.'
                        })
                    )
                ),
                el('div', { className: 'sd-container' },
                    el('button', { className: 'sd-download-button', disabled: true },
                        attributes.iconSVG && el('span', { dangerouslySetInnerHTML: { __html: attributes.iconSVG } }),
                        attributes.buttonText
                    )
                )
            );
        },
        save: function () {
            return null; // Dynamic rendering in PHP
        }
    });
})(window.wp.blocks, window.wp.editor, window.wp.element, window.wp.components);
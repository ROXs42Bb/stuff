<?php
/**
 * Plugin Name: Simple Share Button
 * Description: A simple share button plugin with Facebook, WhatsApp, Telegram, X (Twitter), and Native Share options.
 * Version: 1.0
 * Author: Vidyarthi
 */

 function simple_share_button_enqueue_style() {
    if ((is_singular(['post', 'page']) || is_front_page()) && simple_share_button_display_condition(get_the_ID())) {
        $style_version = filemtime(plugin_dir_path(__FILE__) . 'style.css');
        wp_enqueue_style('simple-share-button-style', plugins_url('style.css', __FILE__), [], $style_version);
    }
}
add_action('wp_enqueue_scripts', 'simple_share_button_enqueue_style');

function simple_share_get_default_svg($platform) {
    $svg_icons = [
        'facebook' => '<svg width="24" height="24" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17 2h-3a5 5 0 00-5 5v3H6v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3V2z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
        'whatsapp' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill-rule="evenodd" fill="#000" clip-rule="evenodd" d="M18.403 5.633A8.919 8.919 0 0 0 12.053 3c-4.948 0-8.976 4.027-8.978 8.977 0 1.582.413 3.126 1.198 4.488L3 21.116l4.759-1.249a8.981 8.981 0 0 0 4.29 1.093h.004c4.947 0 8.975-4.027 8.977-8.977a8.926 8.926 0 0 0-2.627-6.35m-6.35 13.812h-.003a7.446 7.446 0 0 1-3.798-1.041l-.272-.162-2.824.741.753-2.753-.177-.282a7.448 7.448 0 0 1-1.141-3.971c.002-4.114 3.349-7.461 7.465-7.461a7.413 7.413 0 0 1 5.275 2.188 7.42 7.42 0 0 1 2.183 5.279c-.002 4.114-3.349 7.462-7.461 7.462m4.093-5.589c-.225-.113-1.327-.655-1.533-.73-.205-.075-.354-.112-.504.112s-.58.729-.711.879-.262.168-.486.056-.947-.349-1.804-1.113c-.667-.595-1.117-1.329-1.248-1.554s-.014-.346.099-.458c.101-.1.224-.262.336-.393.112-.131.149-.224.224-.374s.038-.281-.019-.393c-.056-.113-.505-1.217-.692-1.666-.181-.435-.366-.377-.504-.383a9.65 9.65 0 0 0-.429-.008.826.826 0 0 0-.599.28c-.206.225-.785.767-.785 1.871s.804 2.171.916 2.321c.112.15 1.582 2.415 3.832 3.387.536.231.954.369 1.279.473.537.171 1.026.146 1.413.089.431-.064 1.327-.542 1.514-1.066.187-.524.187-.973.131-1.067-.056-.094-.207-.151-.43-.263"></path></svg>',
        'telegram' => '<svg width="24" height="24" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 5L2 12.5l7 1M21 5l-2.5 15L9 13.5M21 5L9 13.5m0 0V19l3.249-3.277" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
        'x' => '<svg width="24px" height="24px" viewBox="0 0 24 24" stroke-width="1.5" fill="none" xmlns="http://www.w3.org/2000/svg" color="#000000"><path d="M16.8198 20.7684L3.75317 3.96836C3.44664 3.57425 3.72749 3 4.22678 3H6.70655C6.8917 3 7.06649 3.08548 7.18016 3.23164L20.2468 20.0316C20.5534 20.4258 20.2725 21 19.7732 21H17.2935C17.1083 21 16.9335 20.9145 16.8198 20.7684Z" stroke="#000000" stroke-width="1.5"></path><path d="M20 3L4 21" stroke="#000000" stroke-width="1.5" stroke-linecap="round"></path></svg>',
        'native' => '<svg width="24px" height="24px" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="#000000"><path d="M18 22C19.6569 22 21 20.6569 21 19C21 17.3431 19.6569 16 18 16C16.3431 16 15 17.3431 15 19C15 20.6569 16.3431 22 18 22Z" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M18 8C19.6569 8 21 6.65685 21 5C21 3.34315 19.6569 2 18 2C16.3431 2 15 3.34315 15 5C15 6.65685 16.3431 8 18 8Z" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M6 15C7.65685 15 9 13.6569 9 12C9 10.3431 7.65685 9 6 9C4.34315 9 3 10.3431 3 12C3 13.6569 4.34315 15 6 15Z" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M15.5 6.5L8.5 10.5" stroke="#000000" stroke-width="1.5"></path><path d="M8.5 13.5L15.5 17.5" stroke="#000000" stroke-width="1.5"></path></svg>',
    ];

    return isset($svg_icons[$platform]) ? $svg_icons[$platform] : '';
}

function simple_share_button_add_admin_menu() {
    add_menu_page(
        'Simple Share Button',
        'Share Button Settings',
        'manage_options',
        'simple-share-button',
        'simple_share_button_options_page'
    );
}
add_action('admin_menu', 'simple_share_button_add_admin_menu');

function simple_share_button_register_settings() {
    register_setting('simple_share_button_options', 'simple_share_display_condition', [
        'default' => 'specific'
    ]);
    register_setting('simple_share_button_options', 'simple_share_selected_ids');
    register_setting('simple_share_button_options', 'simple_share_excluded_ids');
}
add_action('admin_init', 'simple_share_button_register_settings');

function simple_share_button_options_page() {
    $display_condition = get_option('simple_share_display_condition', 'specific');
    $selected_ids = get_option('simple_share_selected_ids', '');
    $excluded_ids = get_option('simple_share_excluded_ids', '');
    ?>
    <div class="wrap">
        <h1>Simple Share Button Settings</h1>
        <form action="options.php" method="post">
            <?php
            settings_fields('simple_share_button_options');
            do_settings_sections('simple_share_button_options');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Display Condition</th>
                    <td>
                        <select name="simple_share_display_condition">
                            <option value="all" <?php selected($display_condition, 'all'); ?>>Show on All Single Posts/Pages</option>
                            <option value="specific" <?php selected($display_condition, 'specific'); ?>>Show on Specific Posts/Pages</option>
                            <option value="exclude" <?php selected($display_condition, 'exclude'); ?>>Hide on Specific Posts/Pages</option>
                            <option value="homepage" <?php selected($display_condition, 'homepage'); ?>>Show on Homepage Only</option>
                        </select>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Include on Specific Posts/Pages</th>
                    <td>
                        <input type="text" name="simple_share_selected_ids" value="<?php echo esc_attr($selected_ids); ?>" placeholder="Enter post/page IDs, comma-separated">
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Exclude from Specific Posts/Pages</th>
                    <td>
                        <input type="text" name="simple_share_excluded_ids" value="<?php echo esc_attr($excluded_ids); ?>" placeholder="Enter post/page IDs, comma-separated">
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

function simple_share_button_display_condition($post_id) {
    $display_condition = get_option('simple_share_display_condition', 'specific');
    $selected_ids = get_option('simple_share_selected_ids', '');
    $excluded_ids = get_option('simple_share_excluded_ids', '');

    if ($display_condition === 'all') {
        return is_singular(['post', 'page']);
    }

    if ($display_condition === 'specific') {
        if (!empty($selected_ids)) {
            $selected_ids_array = explode(',', $selected_ids);
            $selected_ids_array = array_map('trim', $selected_ids_array);
            return in_array($post_id, $selected_ids_array);
        }
        return false;
    }

    if ($display_condition === 'exclude') {
        if (!empty($excluded_ids)) {
            $excluded_ids_array = explode(',', $excluded_ids);
            $excluded_ids_array = array_map('trim', $excluded_ids_array);
            return !in_array($post_id, $excluded_ids_array);
        }
        return true;
    }

    if ($display_condition === 'homepage') {
        return is_front_page();
    }

    return false;
}
function simple_share_button_display($content) {
    global $post;

    $post_title = rawurlencode(get_the_title());
    $post_permalink = esc_url(get_permalink());

    if ((is_singular(['post', 'page']) || is_front_page()) && simple_share_button_display_condition(get_the_ID())) {
        $share_buttons = '<div class="simple-share-button">';
        $share_buttons .= '<a class="facebook-share-button" href="https://www.facebook.com/sharer/sharer.php?u=' . $post_permalink . '&t=' . $post_title . '" target="_blank" rel="nofollow noreferrer" aria-label="Share on Facebook" title="Share on Facebook">' . simple_share_get_default_svg('facebook') . '</a>';
        $share_buttons .= '<a class="whatsapp-share-button" href="https://wa.me/?text=' . $post_title . ' - ' . $post_permalink . '" target="_blank" rel="nofollow noreferrer" aria-label="Share on WhatsApp" title="Share on WhatsApp">' . simple_share_get_default_svg('whatsapp') . '</a>';
        $share_buttons .= '<a class="telegram-share-button" href="https://telegram.me/share/url?text=' . $post_title . '&url=' . $post_permalink . '" target="_blank" rel="nofollow noreferrer" aria-label="Share on Telegram" title="Share on Telegram">' . simple_share_get_default_svg('telegram') . '</a>';
        $share_buttons .= '<a class="x-share-button" href="https://twitter.com/intent/tweet?text=' . $post_title . ' - ' . $post_permalink . '" target="_blank" rel="nofollow noreferrer" aria-label="Share on X (formerly Twitter)" title="Share on X (formerly Twitter)">' . simple_share_get_default_svg('x') . '</a>';
        $share_buttons .= '<a class="native-share-button" href="javascript:void(0);" onclick="if (navigator.share) { navigator.share({ url: \'' . $post_permalink . '\' }); } return false;" rel="nofollow noreferrer" aria-label="Share using native share" title="Share using native share">' . simple_share_get_default_svg('native') . '</a>';
        $share_buttons .= '</div>';

        return $content . $share_buttons;
    }

    return $content;
}
add_filter('the_content', 'simple_share_button_display');

